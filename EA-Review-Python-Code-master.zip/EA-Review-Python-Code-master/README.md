# EA-Review-Python-Code
pulls out information from individual Enterprise Architecture Review Forms and automatically inputs it on a master sheet. 
